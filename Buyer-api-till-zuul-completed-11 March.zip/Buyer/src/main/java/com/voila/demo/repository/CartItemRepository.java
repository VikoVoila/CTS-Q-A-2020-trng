package com.voila.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.model.CartItems;

public interface CartItemRepository extends JpaRepository<CartItems, Integer>{
	@Query(value = "select * from cart_items where buyer_id=?1", nativeQuery = true )
	public List<CartItems> getCartItemByBuyerId(Integer buyerId);
}
