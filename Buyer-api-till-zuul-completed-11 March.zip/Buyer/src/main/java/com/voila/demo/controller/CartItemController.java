package com.voila.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.model.CartItems;
import com.voila.demo.model.PurchaseHistory;
import com.voila.demo.model.Transactions;
import com.voila.demo.model.service.BuyersInfoService;
import com.voila.demo.model.service.CartItemService;
import com.voila.demo.model.service.PurchaseService;
import com.voila.demo.repository.BuyerRepository;

@RestController
@CrossOrigin("*")
public class CartItemController {
	
	/* private final BuyerRepository repository; */
	@Autowired
	private CartItemService cartItemService;
	
	@Autowired
	private PurchaseService purchaseService;
	
	/*
	 * public BuyerController(BuyerRepository repository) { // TODO Auto-generated
	 * constructor stub this.repository = repository; }
	 */
	
	// url mappings
	/*
	 * @PostMapping("/buyersinfo") BuyerInfo newBuyerInfo(@RequestBody BuyerInfo
	 * newBuyerInfo) { return repository.save(newBuyerInfo); }
	 */
	// get all buyer
	@RequestMapping("/cartitems")    
	public List<CartItems> getAllItem()  
	{    
	return cartItemService.getAllCartItems();    
	} 
	
	// post method to insert new cartitem details
	
	  @PostMapping("/buyer/addcartitems/{buyerId}") 
	  public CartItems newCartItems(@RequestBody CartItems newCartItems, @PathVariable ("buyerId")Integer buyerId) { 
		  System.out.println("in cartitemcontroller");
		  CartItems cartitem = cartItemService.addCartItem(newCartItems, buyerId); 
		  return cartitem;
	 }
	 
	  
	// getById method
		
	   @GetMapping("/{buyerId}/getcartitems") 
	   public List<CartItems> cartItemByBuyerId(@PathVariable(value="buyerId") Integer buyerId) {
		return cartItemService.getCartItems(buyerId);
			
	  }
	   @PostMapping("/cartitems/checkout/{buyerID}")
	   public String chekOoutByBuyerId(@PathVariable (value="buyerID") Integer buyerId, @RequestBody Transactions transaction) {
		return purchaseService.checkOut(transaction, buyerId);
		   
	   }
	   
	   @PutMapping("/cartitem/{buyerId}")
	   public CartItems updateCartQuantity(@RequestBody CartItems cartItem) {
		   System.out.println("hi"+cartItem);
		   return cartItemService.incDecItem(cartItem);
	   }
	// getById method
	/*
	 * @GetMapping("/buyersinfo/{id}") public BuyerInfo
	 * getBuyerInfo(@PathVariable(value="id") Integer buyerId) { Optional<BuyerInfo>
	 * showBuyer = buyerservice.getBuyer(buyerId); return showBuyer.get(); }
	 */
	// Delete cartitem updated 7 march
	   @DeleteMapping("/deletecartitem/{carItemId}") 
	   public void deleteCartItemByBuyerId(@PathVariable("carItemId") Integer carItemId) {
	   cartItemService.deleteCartItem(carItemId); 
	   }
	
	// Delete Buyer
	/*
	 * @DeleteMapping("/buyersinfo/{buyerId}") private void
	 * deleteBuyerInfo(@PathVariable("buyerId") int buyerId) {
	 * buyerservice.deleteBuyersInfo(buyerId); }
	 * 
	 * // Update BuyersInfo
	 * 
	 * @PutMapping("/buyersinfo/{id}") private BuyerInfo
	 * updateBuyersInfo(@RequestBody BuyerInfo buyersInfo) {
	 * buyerservice.saveOrUpdate(buyersInfo); return buyersInfo; }
	 */
	
	
	@GetMapping("")
	
	
	@RequestMapping("/cart")
	public String sayHi() {
		return "Hi Cart-Items";
	}
}
