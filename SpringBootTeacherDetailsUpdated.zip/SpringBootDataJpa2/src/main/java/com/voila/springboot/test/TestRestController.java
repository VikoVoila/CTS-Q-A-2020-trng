package com.voila.springboot.test;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestRestController {
	@Autowired
	private ITeacherService service;
	
	@RequestMapping("getAll")
	public List<Teacher> getAll(){
		return service.getAllTeachers();
	}
	@RequestMapping("getById/{eid}")
	public Teacher getbyId(@PathVariable("eid") int pid) {
		
		Optional<Teacher> t=service.getTeacherById(pid);
		Teacher tObj=null;
		if(t.isPresent()){
		 tObj=t.get();	
		}		
		return tObj;
	}
	
	@RequestMapping("getByName/{ename}")
	public Teacher getbyName(@PathVariable("ename") String name) {
		return service.getTeacherByName(name);
		
	}
	
	//Add new Teacher
	@PostMapping("/teacher")
	public Teacher addTeacher(@Valid @RequestBody Teacher teacher) {
		return service.addTeacher(teacher);
	}
	
	// Update Teacher details
	@PutMapping("/teacherupdate/{id}")
	public Integer updateTeacher(@PathVariable(value="id") int id, @RequestBody Teacher teacher) {
		
		return service.updateTeacher(id, teacher);
		
	}
}
