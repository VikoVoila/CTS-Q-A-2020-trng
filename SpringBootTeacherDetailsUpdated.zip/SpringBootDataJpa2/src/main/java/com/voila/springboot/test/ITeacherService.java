package com.voila.springboot.test;

import java.util.List;
import java.util.Optional;

public interface ITeacherService {
	
	public List<Teacher> getAllTeachers();
	public Optional<Teacher> getTeacherById(int id);
	public Teacher getTeacherByName(String name) ;
	public Teacher findUsingNameAddr(String name,String addr);
	// add teacher method
	public Teacher addTeacher(Teacher teacher);
	
	// update teacher details
	public Integer updateTeacher(int id, Teacher teacher);
}
