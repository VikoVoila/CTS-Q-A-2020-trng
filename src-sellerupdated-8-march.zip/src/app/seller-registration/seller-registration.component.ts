import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SellerModel } from '../models/seller.model';
import { SellerRegistrationService } from '../service/seller-registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seller-registration',
  templateUrl: './seller-registration.component.html',
  styleUrls: ['./seller-registration.component.css']
})
export class SellerRegistrationComponent implements OnInit {

  form = new FormGroup({
    sellerName: new FormControl('', Validators.required),
    companyName: new FormControl('', Validators.required),
    companyDescription: new FormControl('', Validators.required),
    cWebsite: new FormControl('', Validators.required),
    gstin: new FormControl('', Validators.required),
    postalAddress: new FormControl('', Validators.required),
    houseNumber: new FormControl('', Validators.required),
    streetName: new FormControl('', Validators.required),
    locality: new FormControl('', Validators.required),
    city: new FormControl('', Validators.required),
    state: new FormControl('', Validators.required),
    pinCode: new FormControl('', [
      Validators.required,
      Validators.pattern("^[0-9]*$"),
      Validators.maxLength(6),
      Validators.minLength(6)
    ]),
    phone: new FormControl('', [
      Validators.required,
      Validators.pattern("^[0-9]*$"),
      Validators.maxLength(10),
      Validators.minLength(10)
    ]),
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
    
   });

   seller: SellerModel = new SellerModel();

  constructor(private router:Router,  private sellerRegistrationService: SellerRegistrationService ) { }

  ngOnInit(): void {
  }

  createSeller(): void {
    console.log(this.seller.emailId);
    this.sellerRegistrationService.createSeller(this.seller)
        .subscribe( () => {
          alert("Buyer created successfully.");
        });

  };

  // convenience getter for easy access to form fields
  // get form1() { return this.form.controls; }

  onSubmit(){
    //alert(JSON.stringify(this.form.value));
    this.createSeller();
  }

}
