package com.voila.hibernate.start.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class EmployeeDetails implements Serializable
{
	
	@Id
	@GeneratedValue
	private int empId;
	@Column(name="employee_name")
	private String name;
	private String mobileNo;
	private String city;
	private String desig;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
	public EmployeeDetails(String name, String mobileNo, String city, String desig) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.city = city;
		this.desig = desig;
	}
	public EmployeeDetails() {
		super();
	}
	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", name=" + name + ", mobileNo=" + mobileNo + ", city=" + city
				+ ", desig=" + desig + "]";
	}
	
	
	
	
}
