package Voila.EmployeeDetailstable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.voila.hibernate.start.model.EmployeeDetails;






/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	
    	Configuration configuration=new Configuration().configure();
    	SessionFactory sf=configuration.buildSessionFactory();
    	Session session=sf.openSession();
    	session.beginTransaction();
    	EmployeeDetails emp = new EmployeeDetails("Varanasi","Maneger","82928138","Voila");
    	EmployeeDetails emp1 = new EmployeeDetails("Lucknow","Sr.Maneger","91220137","Abhi");
    	
       	session.save(emp);
       	session.save(emp1);
    	session.getTransaction().commit();
       	
       	
     /*---------------------------------------------------------------------------------------*/
    		
		/*
		 * EmployeeDetails e=(EmployeeDetails)session.get(EmployeeDetails.class,123);
		 * System.out.println(e);
		 */
		
    }
}
