package com.voila.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.voila.model.Product;

public class SpringJdbcT {
	
	public static void main(String args[]) throws SQLException {
		SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
		dataSource.setDriver(new com.mysql.jdbc.Driver());
		dataSource.setUrl("jdbc:mysql://localhost/project");
		dataSource.setUsername("root");
		dataSource.setPassword("pass");
		
		JdbcTemplate jdbcTemp = new JdbcTemplate(dataSource);
		String sqlInsert="INSERT INTO product (id, name, qty, price)"
                + " VALUES (?, ?, ?, ?)";
		jdbcTemp.update(sqlInsert, "123", "tomea", "54", "123.45");
        
        String sqlUpdate = "UPDATE contact set id=? where name=?";
        jdbcTemp.update(sqlUpdate, "12", "Tom");
         
        String sqlSelect = "SELECT * FROM contact";
        
		/*
		 * List<Product> listContact = jdbcTemp.query(sqlSelect, new
		 * RowMapper<Product>() {
		 * 
		 * public Product mapRow(ResultSet result, int rowNum) throws SQLException {
		 * Product product = new Product();
		 * 
		 * product.setName(name);; product.setQty(result.getString("qty"));
		 * product.setPrice(result.getString("price"));
		 * 
		 * return contact; }
		 * 
		 * });
		 */
	}

}
