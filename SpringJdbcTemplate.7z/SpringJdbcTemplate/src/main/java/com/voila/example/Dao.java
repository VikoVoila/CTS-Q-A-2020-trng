package com.voila.example;

public class Dao {

}
