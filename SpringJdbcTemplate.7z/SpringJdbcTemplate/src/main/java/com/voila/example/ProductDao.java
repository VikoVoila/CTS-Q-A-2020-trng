package com.voila.example;
/*Author - 
Ref - https://www.logicbig.com/tutorials/spring-framework/spring-data-access-with-jdbc/connect-my-sql.html*/

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;

@Repository
public class ProductDao {
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemp;
	private SimpleJdbcInsert jdbcInsert;
	
	@PostConstruct
	private void PostConstruct() {
		jdbcTemp = new JdbcTemplate(dataSource);
        jdbcInsert = new SimpleJdbcInsert(dataSource)
        		.withTableName("product").usingGeneratedKeyColumns("ID");
		
	}
	
	 @Override
	    public void save(Product product) {
	        SqlParameterSource parameters = new BeanPropertySqlParameterSource(product);
	        jdbcInsert.execute(parameters);
	    }
	 
	 @Override
	    public Product load(long id) {
	        List<Product> persons = jdbcTemp.query("select * from Person where id =?",
	                new Object[]{id}, (resultSet, i) -> {
	                    return toPerson(resultSet);
	                });

	        if (persons.size() == 1) {
	            return persons.get(0);
	        }
	        return null;
	    }

	    @Override
	    public void delete(long id) {
	        jdbcTemplate.update("delete from PERSON where id = ?", id);
	    }

	    @Override
	    public void update(Product product) {
	        throw new UnsupportedOperationException();
	    }


	    @Override
	    public List<Product> loadAll() {
	        return jdbcTemp.query("select * from Person", (resultSet, i) -> {
	            return toPerson(resultSet);
	        });
	    }
	    
	    private Product toPerson(ResultSet resultSet) throws SQLException {
	    	Product product = new Product();
	    	product.setId(resultSet.getLong("prodid"));
	    	product.setName(resultSet.getString("proname"));
	    	product.setQty(qty);(resultSet.getString("qty"));
	    	product.setAddress(resultSet.getString("price"));
	        return product;
	    }


}
