package com.voila.example;

public class AppConfig {

}
