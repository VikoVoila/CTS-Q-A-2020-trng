export class BuyerModel {
    name: string;
    emailId: string;
    password: string;
    mobileNo: number;
}