package com.voila.FirstSpring;

import org.springframework.stereotype.Component;

@Component
// with @Component 
public class Bike implements Vehicle{
	
	public void drive() {
		System.out.println("Bike Bhag rhi h..");
	}
}
