package com.voila.FirstSpring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//BeanFactory
    	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
    	
        System.out.println( "Hello World! -  Autowired" );
        Car obj= (Car)context.getBean("car");// here bike is nothing but Bike class object which is implicitly make small letter (bike)
        obj.drive();
        
       // Tyre t=new Tyre();
        //whenever we use new keyword there is dependency so to remove this
        
        /*Tyre t=(Tyre)context.getBean("tyre");
        System.out.println(t);*/
    }
}
