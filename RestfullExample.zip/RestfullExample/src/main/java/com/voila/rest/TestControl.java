package com.voila.rest;

import java.util.HashMap;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestControl {
	
	HashMap<Integer, Product> hm = new HashMap<Integer, Product>();
	
	@RequestMapping("/jason")
	public HashMap<Integer, Product> TestControl() {
		hm.put(102, new Product(121, "Washing Mcn", 43, 28273.9f));
		hm.put(103, new Product(121, "Refg Mcn", 3, 28273.0f));
		hm.put(104, new Product(121, "Cooler Mcn", 143, 28273.2f));
		return hm;
		
	}
	
	
	@RequestMapping(value="/getbyid/{pid}",method = RequestMethod.GET)
	public Product getById(@PathVariable("pid") int id) {
		
		return hm.get(id);
		
	}
	
	@RequestMapping("/data")
	public String display() {
		
		return "Hello!";
	}
	
	@RequestMapping("/jsonData")
	public String display1() {
		
		return "Hi..!";
	}
}
