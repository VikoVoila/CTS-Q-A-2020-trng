package com.voila.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="cart_items")
public class CartItems {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cartItemId;
	
	private Integer itemId;
	
	private Integer quantity;
	
	@Column(name="item_price")
	private Float price;
	
	@ManyToOne
	@JoinColumn(name = "buyer_id")
	private BuyerInfo buyer;
	
	

	public CartItems() {
		super();
	}

	public CartItems(Integer cartItemId, Integer itemId, Integer quantity, BuyerInfo buyer, Float price) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.price = price;
		this.buyer = buyer;
	}

	public Integer getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(Integer cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	
	

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public BuyerInfo getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}

	@Override
	public String toString() {
		return "CartItems [cartItemId=" + cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + ", price="
				+ price + ", buyer=" + buyer + "]";
	}
	
	
	
	
	
}
