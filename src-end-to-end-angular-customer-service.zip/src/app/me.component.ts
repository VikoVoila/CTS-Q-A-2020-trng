import { Component } from '@angular/core';

@Component({
  selector: 'app-security',
  template: `<h2>Voila2678</h2>`
})
export class meComponent { }