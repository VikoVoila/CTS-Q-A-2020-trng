package com.voilla;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class ReqParamController {
	@RequestMapping(method = RequestMethod.GET)
	public String redirect() {
		return "index";
	}
	@RequestMapping("/hello")
	public String display(@RequestParam("name") String name,  @RequestParam("pass") String pass, Model m) {
		if (pass.equals("admin")) {
			String msg="Hello "+ name;
			
			 m.addAttribute("message", msg);  
	            return "viewpage";  
		}else {
			String msg="Sorry "+ name+". You entered an incorrect password";  
            m.addAttribute("message", msg);  
            return "errorpage";  
		}
	}

}
