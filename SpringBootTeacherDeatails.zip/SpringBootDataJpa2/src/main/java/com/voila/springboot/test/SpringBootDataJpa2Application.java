package com.voila.springboot.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(entityManagerFactoryRef="entityManagerFactory", basePackages="com.voila.*")
public class SpringBootDataJpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJpa2Application.class, args);
	}

}
