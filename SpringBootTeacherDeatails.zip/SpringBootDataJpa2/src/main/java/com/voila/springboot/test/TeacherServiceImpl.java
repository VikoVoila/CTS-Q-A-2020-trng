package com.voila.springboot.test;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class TeacherServiceImpl implements ITeacherService {
	
	@Autowired
	private ITeacherDao dao;
	@Override
	public List<Teacher> getAllTeachers() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Optional<Teacher> getTeacherById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	@Override
	public Teacher getTeacherByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Teacher findUsingNameAddr(String name, String addr) {
		// TODO Auto-generated method stub
		return null;
	}

}
