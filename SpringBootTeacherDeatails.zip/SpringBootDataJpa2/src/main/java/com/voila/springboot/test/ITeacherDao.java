package com.voila.springboot.test;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ITeacherDao extends JpaRepositoryImplementation<Teacher, Integer>{
	
	@Query(value="FROM Teacher t where t.name =:tn")
	public Teacher findByname(@Param("tn") String name);
	
	@Query(value="FROM Teacher t where t.name =:tn and t.dept=:dept")
	public Teacher findUsingNameDept(@Param("tn")String n, @Param("dept") String ad);
	
}
