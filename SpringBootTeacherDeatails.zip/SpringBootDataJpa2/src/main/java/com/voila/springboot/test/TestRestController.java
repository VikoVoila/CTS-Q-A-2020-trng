package com.voila.springboot.test;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestRestController {
	@Autowired
	private ITeacherService service;
	
	@RequestMapping("getAll")
	public List<Teacher> getAll(){
		return service.getAllTeachers();
	}
	@RequestMapping("getById/{eid}")
	public Teacher getbyId(@PathVariable("eid") int pid) {
		
		Optional<Teacher> t=service.getTeacherById(pid);
		Teacher tObj=null;
		if(t.isPresent()){
		 tObj=t.get();	
		}		
		return tObj;
	}
}
