package com.voila.springboot.test;

import java.util.List;
import java.util.Optional;

public interface ITeacherService {
	
	public List<Teacher> getAllTeachers();
	public Optional<Teacher> getTeacherById(int id);
	public Teacher getTeacherByName(String name) ;
	public Teacher findUsingNameAddr(String name,String addr);
}
