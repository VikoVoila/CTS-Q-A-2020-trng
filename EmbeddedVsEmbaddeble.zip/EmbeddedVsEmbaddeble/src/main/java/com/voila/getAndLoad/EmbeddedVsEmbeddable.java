package com.voila.getAndLoad;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.voila.mypackage.Customer;
import com.voila.mypackage.Name;


/**
 * Hello world!
 *
 */
public class EmbeddedVsEmbeddable 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		session.getTransaction().begin();
		
		Name name = new Name();
		name.setfName("voila");
		name.setlName("28");
		Customer c = new Customer();
		c.setcId(23);
		c.setName(name);
		session.save(c);
		session.getTransaction().commit();
		session.close();
				
		
    }
}
