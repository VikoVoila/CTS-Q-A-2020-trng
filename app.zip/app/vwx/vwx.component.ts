import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vwx',
  templateUrl: './vwx.component.html',
  styleUrls: ['./vwx.component.css']
})
export class VwxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  ids=[1,2,3,4,5];

}
