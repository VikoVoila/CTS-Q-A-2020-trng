import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PqrComponent } from './pqr/pqr.component';
import { StuComponent } from './stu/stu.component';
import { VwxComponent } from './vwx/vwx.component';

@NgModule({
  declarations: [
    AppComponent,
    PqrComponent,
    StuComponent,
    VwxComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
