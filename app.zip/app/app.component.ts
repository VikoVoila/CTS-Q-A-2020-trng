import { Component } from '@angular/core';
import {User} from'./users';
import { from } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isValid = true;
 ids=[1,2,3,4,5];
  title = 'my-app';
  count = 0;

  i=0;
  myfuncInc(){
    console.log("You just Clicked");
    this.i++;
  }
  myfuncDec(){
    console.log("You just Clicked");
    this.i--;
  }
  name:string='abcdef';
	welcomeText:string;
	
	constructor() { 
    this.name = 'pink';
    this.welcomeText= 'You are welcome';
    console.log('aaaaaaaaaaaaa');
  }
  shide(){
    this.isValid=!this.isValid;}
    /*if (this.isValid = !this.isValid) {
      this.isValid=false;
    }else{
      this.isValid=true;
    }
  }*/
  even(){
    this.count++;
  }
  Users: User[]= [
    new User('Mahesh', 20, 'bkasdg@g.com'),
    new User('Mahesh2', 23,'bkasdg@g.com'),
    new User('Mahesh3', 24, 'bkasdg@g.com'),
  ]
  value;
  clicked(){
    this.count++;
    switch (this.count){
      case 1:
        this.value = 'one';
        break;
      case 2:
        this.value = 'two';
        break;
      case 3:
        this.value = 'three';
        break;
      default:
        this.count=1;
        this.value = 'one';
        break;
    }
  }


  
  
}
/*
export class User {
  constructor(public name: string, 
    public age: number, 
    public email: String
    ){
}}
*/