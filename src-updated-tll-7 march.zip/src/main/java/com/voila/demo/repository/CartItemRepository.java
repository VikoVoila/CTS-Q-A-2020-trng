package com.voila.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.model.CartItems;

public interface CartItemRepository extends JpaRepository<CartItems, Integer>{

}
