package com.voila.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.model.CartItems;
import com.voila.demo.model.service.BuyersInfoService;
import com.voila.demo.model.service.CartItemService;
import com.voila.demo.repository.BuyerRepository;

@RestController
public class CartItemController {
	
	/* private final BuyerRepository repository; */
	@Autowired
	private CartItemService cartItemService;
	
	/*
	 * public BuyerController(BuyerRepository repository) { // TODO Auto-generated
	 * constructor stub this.repository = repository; }
	 */
	
	// url mappings
	/*
	 * @PostMapping("/buyersinfo") BuyerInfo newBuyerInfo(@RequestBody BuyerInfo
	 * newBuyerInfo) { return repository.save(newBuyerInfo); }
	 */
	// get all cartitems
	@RequestMapping("/cartitems")    
	public List<CartItems> getAllItem()  
	{    
	return cartItemService.getAllCartItems();    
	} 
	
	// post method to insert new cartitem
	
	  @PostMapping("/buyer/{buyerId}/cartitems") 
	  public CartItems newCartItems(@RequestBody CartItems newCartItems) { 
		  System.out.println("in cartitemcontroller");
		  CartItems cartitem = cartItemService.addCartItem(newCartItems); 
		  return cartitem;
	 }
	 
	
	// getById method
	
	  @GetMapping("/cartitem/{cartItemId}") 
	  public CartItems cartItemById(@PathVariable(value="cartItemId") Integer cartId) { 
		  Optional<CartItems> showCartItems = cartItemService.getCartItems(cartId); 
		  return showCartItems.get(); 
	  }
	 
	
	// Delete Buyer
	
	  @DeleteMapping("/cartitem/{cartItemId}") 
	  private void deleteCartItem(@PathVariable("cartItemId") int cartId) {
		  cartItemService.deleteItem(cartId); 
	  }
	  
	  // Update BuyersInfo
	  
	
	  @PutMapping("/cartitem/{cartItemId}") 
	  private CartItems updateCartItem(@PathVariable int cartItemId, @RequestBody CartItems cartItems) {
		  cartItemService.saveOrUpdate(cartItemId); 
		  return cartItems;  
	  }
	  
	 
	
	@GetMapping("")
	
	
	@RequestMapping("/cart")
	public String sayHi() {
		return "Hi Cart-Items";
	}
}
