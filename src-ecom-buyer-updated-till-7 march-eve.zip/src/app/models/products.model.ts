import { SellerModel } from './seller.model';

export class ProductsModel {
    productId:number;
    productName: string;
    manufacturer: string;
    model: string;
    seller: SellerModel = new SellerModel();
    price: number;
    stock: number;
    //name:string;
    decription: string;
}