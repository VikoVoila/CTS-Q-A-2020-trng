package com.voila.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.voila.demo.model.BuyerInfo;

public interface BuyerRepository extends JpaRepository<BuyerInfo, Integer>{

	BuyerInfo findByname(String username);

}
