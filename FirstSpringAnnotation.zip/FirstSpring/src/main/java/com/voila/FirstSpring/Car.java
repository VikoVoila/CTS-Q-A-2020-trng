package com.voila.FirstSpring;

import org.springframework.stereotype.Component;

@Component
public class Car implements Vehicle{
	
	public void drive() {
		System.out.println("Car Chal Rhi h... 	");
	}

}
