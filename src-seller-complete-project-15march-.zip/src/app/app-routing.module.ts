import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SellerRegistrationComponent } from './seller-registration/seller-registration.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { HomeComponent } from './home/home.component';
import { SellerLoginComponent } from './seller-login/seller-login.component';
import { SellerLogoutComponent } from './seller-logout/seller-logout.component';
import { RouteGaurdService } from './service/route-gaurd.service';


const routes: Routes = [
  { path: 'sellerreg', component: SellerRegistrationComponent },
  { path: 'addproduct', component: AddproductComponent },
  { path: 'home', component: HomeComponent, canActivate: [RouteGaurdService] },
  { path: 'login', component: SellerLoginComponent },
  { path: 'logout', component: SellerLogoutComponent, canActivate: [RouteGaurdService] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
