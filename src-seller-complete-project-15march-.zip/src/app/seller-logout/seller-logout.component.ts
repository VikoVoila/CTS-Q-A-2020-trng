import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seller-logout',
  templateUrl: './seller-logout.component.html',
  styleUrls: ['./seller-logout.component.css']
})
export class SellerLogoutComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit(): void {
    window.localStorage.removeItem('token');
    window.localStorage.removeItem('name');
    window.localStorage.removeItem('id');
    console.log('logged out !...');
    this.route.navigate(['home']);
    alert("logged out succesfully :)")
  }

}
