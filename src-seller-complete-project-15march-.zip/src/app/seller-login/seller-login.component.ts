import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SellerLoginService } from '../service/seller-login.service';

@Component({
  selector: 'app-seller-login',
  templateUrl: './seller-login.component.html',
  styleUrls: ['./seller-login.component.css']
})
export class SellerLoginComponent implements OnInit {

  loginForm: FormGroup;
  invalidLogin: boolean = false;
  
  constructor(private formBuilder : FormBuilder, private router: Router, private sellerLoginService: SellerLoginService) { }

  userForm : any;

  ngOnInit(): void {
    window.localStorage.removeItem('token');
    this.loginForm = this.formBuilder.group({
      name: ['',[Validators.required]],
      password: ['',[Validators.required]],
    });
  }

  onSubmit(){
    if (this.loginForm.invalid) {
      return;
    }
    console.log("clicked 1 ")
    const loginPayload = {
      username: this.loginForm.controls.name.value,
      password: this.loginForm.controls.password.value
    }
    this.sellerLoginService.login(loginPayload).subscribe(data => {
      //debugger;
      console.log('before ', + this.sellerLoginService.isUserLogedIn())
      if(data.status === 200) {
        window.localStorage.setItem('token', data.result.token);
        window.localStorage.setItem('name', data.result.username);
        window.localStorage.setItem('id', data.result.id);
        console.log('after ', + this.sellerLoginService.isUserLogedIn())
        alert("login successful");
        this.router.navigateByUrl("/addproduct");
      }else {
        this.invalidLogin = true;
        alert(data.message);
      }
    });
    
    console.log("clicked 2 ")
  }

}
