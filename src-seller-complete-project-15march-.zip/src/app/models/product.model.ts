import { SellerModel } from './seller.model';

export class ProductModel {
    productName: string;
    manufacturer:string;
    model:string;
    seller:SellerModel = new SellerModel();
    price:number;
    
    stock:number;
    categoryId:number;
    subCategoryId:number;
    // categoryId: CategoryModel = new CategoryModel();
    // subCategoryId: SubCategoryModel = new SubCategoryModel();
    description:string;
    remarks:string;
}


export class CategoryModel{
    categoryId:number;
    categoryName:string;
    briefDetails:string;
}

export class SubCategoryModel{
    subCategoryId:number;
    subCategoryName:string;
    briefDetails:string;
    gst:number;
    category: CategoryModel = new CategoryModel();
}

