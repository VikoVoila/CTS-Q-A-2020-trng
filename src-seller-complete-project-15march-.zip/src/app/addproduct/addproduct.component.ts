import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AddProductService } from '../service/add-product.service';
import { ProductModel } from '../models/product.model';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  form: FormGroup;
  product: any;

  constructor(private formBuilder: FormBuilder, private router: Router, private addProductService: AddProductService) { }

  get firstname(){
    return this.form.get('firstName')
  }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      productName: new FormControl('', Validators.required),
      manufacturerName: new FormControl('', Validators.required),
      modelName: new FormControl('', Validators.required),
      category : new FormControl('', Validators.required),
      subCategory: new FormControl('', Validators.required),
      price: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\d+\.\d{2}$/),  
      ]),
      stock: new FormControl('', Validators.required),
      remarks: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required)
    })
  }


  addProduct(): void {
    //console.log(this.seller.emailId);
    this.addProductService.addProductToStock(this.product)
      .subscribe(() => {
        alert("Product Added successfully.");
      });

  };


  onSubmit(){
    console.log("on click")
    this.product = new ProductModel();
    this.product.productName = this.form.controls.productName.value;
    console.log(this.product)
    this.product.manufacturer = this.form.controls.manufacturerName.value;
    this.product.model = this.form.controls.modelName.value;
    this.product.price = this.form.controls.price.value;
    this.product.stock= this.form.controls.stock.value;
    this.product.remarks = this.form.controls.remarks.value;
    this.product.description = this.form.controls.description.value;
    this.product.category = this.form.controls.category.value;
    this.product.subCategory = this.form.controls.subCategory.value;
    console.log(this.product)
    console.log("on click2")
    this.addProductService.addProductToStock(this.product).subscribe(() => {
      alert("Added successfully!!!");
    });
    alert(JSON.stringify(this.form.value));
  }

}
