import { TestBed } from '@angular/core/testing';

import { SellerLogoutService } from './seller-logout.service';

describe('SellerLogoutService', () => {
  let service: SellerLogoutService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SellerLogoutService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
