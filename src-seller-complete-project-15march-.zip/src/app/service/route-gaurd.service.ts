import { Injectable } from '@angular/core';
import { SellerLoginService } from './seller-login.service';
import { Router, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouteGaurdService {

  constructor( private sellerLoginService: SellerLoginService, private router:Router ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    // console.log("canActivate ")
    if (this.sellerLoginService.isUserLogedIn())
      return true;

      this.router.navigate(['userlogin'])
      // above is navigating to login if we r in logout condition and typing url 
    return false;
  }
}
