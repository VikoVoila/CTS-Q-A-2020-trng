import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from '../models/seller.model';

@Injectable({
  providedIn: 'root'
})
export class SellerLoginService {

  constructor(private http:HttpClient) { }

  login(loginPayload) : Observable<ApiResponse> {
    // return this.http.post<ApiResponse>('http://localhost:8080/' + 'token/generate-token', loginPayload);
    return this.http.post<ApiResponse>('http://localhost:8989/mentorportal/sellerService/' + 'token/generate-token', loginPayload);
  }

  isUserLogedIn(){
    let user = window.localStorage.getItem('token')
    return !(user === null)
  }


}
