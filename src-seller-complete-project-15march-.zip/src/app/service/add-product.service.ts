import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AddproductComponent } from '../addproduct/addproduct.component';
import { ProductModel } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class AddProductService {

  constructor(private http: HttpClient) { }

  // private baseUrl = "http://localhost:8182/";
  private baseUrl = "http://localhost:8989/mentorportal/sellerService";

  public addProductToStock(product: ProductModel):Observable<any> {
    console.log("in prod service");
    alert(JSON.stringify(product));
    return this.http.post<AddproductComponent>(this.baseUrl+`/product/14`, product);
  }

}
