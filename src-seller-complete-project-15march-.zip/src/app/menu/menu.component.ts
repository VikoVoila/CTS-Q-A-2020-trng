import { Component, OnInit } from '@angular/core';
import { SellerLoginService } from '../service/seller-login.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(public sellerLoginService: SellerLoginService) { }

  ngOnInit(): void {
  }

}
