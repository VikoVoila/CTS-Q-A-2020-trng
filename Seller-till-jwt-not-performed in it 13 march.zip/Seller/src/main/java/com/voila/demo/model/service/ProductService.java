package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.voila.demo.model.CartResponse;
import com.voila.demo.model.Product;
import com.voila.demo.model.Seller;
import com.voila.demo.repository.ProductRepository;
import com.voila.demo.repository.SellerRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private SellerRepository sellerRepository;
	/*
	 * @Autowired private BuyerRepository buyerRepository;
	 */


	public List<Product> getAllProducts() { // TODO Auto-generated method stub
		List<Product> allProducts = new ArrayList<Product>();
		productRepository.findAll().forEach(allProducts::add);
		return allProducts;
	}


	// add new product details
	public Product addProduct(Product newProduct, Integer sellerId) {
		System.out.println("hi");
		Optional<Seller> seller = sellerRepository.findById(sellerId);
		newProduct.setSeller(seller.get());
		System.out.println("hi  "+newProduct);
		return productRepository.save(newProduct);

	}


	public List<Product> getSearchProduct(Product newProduct) {

		return productRepository.findProduct(newProduct.getProductName()); }


//	public void deleteitem(Integer sellerId, Integer itemId) {
//		productRepository.deleteItemById(sellerId, itemId);
//	}
	
	// update product
	public Product updateProduct(Product product, Integer productId) {
		Optional<Product> oldProduct = productRepository.findById(productId);
		if(oldProduct.isPresent()) {
			Product updatedProduct = oldProduct.get();
			updatedProduct.setCategoryId(product.getCategoryId());
			updatedProduct.setDescription(product.getDescription());
			updatedProduct.setProductName(product.getProductName());
			updatedProduct.setRemarks(product.getRemarks());
			updatedProduct.setStock(product.getStock());
			updatedProduct.setPrice(product.getPrice());
			updatedProduct.setSubCategoryId(product.getSubCategoryId());
			return productRepository.save(updatedProduct);
		}
		return null;
	}
	
	// update stock from Allproducts stock
	public void updateStock(List<CartResponse> cartResponse) {
		for(CartResponse cart : cartResponse) {
			System.out.println(cart.getItemId());
		Optional<Product> product = productRepository.findById(cart.getItemId());
		Product updatedProduct = product.get();
		Integer initialQuantity = updatedProduct.getStock();
		updatedProduct.setStock(initialQuantity - cart.getQuantity());
		productRepository.save(updatedProduct);
		}
	}
	
	
	/*
	 * public Product addCartItem(Product newCartItems, Integer buyerId) { // TODO
	 * Auto-generated method stub System.out.println("In service");
	 * Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
	 * newCartItems.setBuyer(buyer.get()); return
	 * cartItemRepository.save(newCartItems); }
	 */



	/*
	 * public List<CartItems> getCartItems(Integer buyerId) { // TODO Auto-generated
	 * method stub
	 * 
	 * return cartItemRepository.getCartItemByBuyerId(buyerId); }
	 */

}
