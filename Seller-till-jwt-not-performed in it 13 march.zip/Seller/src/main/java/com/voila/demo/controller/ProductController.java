package com.voila.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.voila.demo.model.CartResponse;
import com.voila.demo.model.Product;
import com.voila.demo.model.service.ProductService;



@RestController
@CrossOrigin("*")
public class ProductController {
	
	/* private final BuyerRepository repository; */
	@Autowired
	private ProductService productService;
	
	/*
	 * public BuyerController(BuyerRepository repository) { // TODO Auto-generated
	 * constructor stub this.repository = repository; }
	 */
	
	// url mappings
	/*
	 * @PostMapping("/buyersinfo") BuyerInfo newBuyerInfo(@RequestBody BuyerInfo
	 * newBuyerInfo) { return repository.save(newBuyerInfo); }
	 */
	// get all buyer
	@RequestMapping("/products")    
	public List<Product> getAllProducts()  
	{    
	return productService.getAllProducts();    
	} 
	
	// post method to insert new product details
	@PostMapping("/product/{sellerId}")
	public Product newProduct(@RequestBody Product newProduct, @PathVariable ("sellerId")Integer sellerId) {
		Product product = productService.addProduct(newProduct, sellerId);
		/* Seller sellerInfo = sellerService.addSeller(newSellerInfo); */
		return product;
	}
	
	
	  @PostMapping("/search") public List<Product> newProduct(@RequestBody Product newProduct) { 
		  return productService.getSearchProduct(newProduct); }
	 
	  @PutMapping("/updatestock")
	 public void updateStock(@RequestBody List<CartResponse> cartResponse) {
		   productService.updateStock(cartResponse);
	   }
	
	
	// getById method
	/*
	 * @GetMapping("/sellerinfo/{id}") public Seller
	 * getBuyerInfo(@PathVariable(value="id") Integer sellerId) { Optional<Seller>
	 * showSeller = sellerService.getSeller(sellerId); return showSeller.get(); }
	 */
	
	// Delete Seller
	/*
	 * @DeleteMapping("/sellerinfo/{sellerId}") private void
	 * deleteSeller(@PathVariable("sellerId") Integer sellerId) {
	 * sellerService.deleteSeller(sellerId); }
	 */
	
	
	
	
	
	@RequestMapping("/sell")
	public String sayHi() {
		return "Hi Seller";
	}
}
