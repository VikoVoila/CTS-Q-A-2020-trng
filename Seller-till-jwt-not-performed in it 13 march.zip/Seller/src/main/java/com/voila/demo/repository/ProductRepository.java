package com.voila.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.voila.demo.model.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{
	/*
	 * @Query(value = "select * from cart_items where buyer_id=?1", nativeQuery =
	 * true ) public List<Product> getCartItemByBuyerId(Integer buyerId);
	 */
	
	
	 @Query(value= "from Product where lower(productName) LIKE %:productName%") 
	 public List<Product> findProduct(@Param("productName") String product);
	 
//	 @Query(value= "from Product where lower(productName) LIKE %:productName%") 
//	public void deleteItemById(Integer sellerId, Integer productId);
	 
	 
	 
}
