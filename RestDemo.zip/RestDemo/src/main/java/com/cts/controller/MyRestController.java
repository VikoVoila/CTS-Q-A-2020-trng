package com.cts.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController // (+respbody)
public class MyRestController {

	Map<Integer, Product> m = new HashMap<>();
	List<Product> listProduct = new ArrayList<>();
	
	public MyRestController() {
		m.put(1001, new Product(1001, "tv", 9, 8990.9f));
		m.put(1002, new Product(1002, "Ac", 6, 3000.9f));
		m.put(1003, new Product(1003, "toy", 13, 399.9f));
		listProduct.add(new Product(1001, "tv", 9, 8990.9f));
		listProduct.add(new Product(1002, "Ac", 6, 3000.9f));
		listProduct.add(new Product(1003, "toy", 13, 399.9f));

	}
	// when @RestController is given its not necessary to give
	// @ResponseBody for every method
	// optional to use produces and consumes

	@RequestMapping(value = "/")
	public String displayMsg() {
		return "hi hello !!!";
	}

	@RequestMapping(value = "/json") // ,produces="application/json")
	public String displayMsg1() {
		// GSON to convert into json repn else its treated as plain text
		// but can apply json in post and check
		String a = "{\"success\": true,   \"payload\": \"succes\"  }";
		return a;
	}

	/*
	 * List l=new ArrayList<>(); public MyRestController() { l.add("hi");
	 * l.add("hello"); l.add(1000); l.add(1000); l.add(100.80f); }
	 * 
	 * @RequestMapping(value = "/jsonList") // ,produces="application/json")
	 * public List displayList() { return l; }
	 */

	@RequestMapping(value = "/jsonMap") // ,produces="application/json")
	public Map<Integer, Product> displayProductMap() {
		return m;
	}

	@RequestMapping(value = "/jsonProductList") // ,produces="application/json")
	public ResponseEntity displayProductList() {
		
		return ResponseEntity.ok().header("").body(listProduct);
		
	}

	@RequestMapping(value = "/getbyid/{pid}", method = RequestMethod.GET)
	public Product displayProductById(@PathVariable("pid") int id) {
		return m.get(id);
	}

	@RequestMapping(value = "{version}/getbyid/{pid}", method = RequestMethod.GET)
	public String displayInfo(@PathVariable("pid") int id, @PathVariable("version") String version) {
		System.out.println(id);
		System.out.println(version);
		return version;
	}

	@RequestMapping(value = "/store", method = RequestMethod.POST)
	public ResponseEntity<Product> storeProduct(@RequestBody Product product) {
		System.out.println(product);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Responsedby", "MyController");
		headers.add("author", "Abc");
		headers.add("Content-Type", "application/json");
		return ResponseEntity.accepted().headers(headers).body(product);
	}
	@RequestMapping(value = "/refresh", method = RequestMethod.GET)
	public ResponseEntity<String> info() {
		String str="<h1>hi hello<h1>";
		HttpHeaders headers = new HttpHeaders();
		headers.add("Responsedby", getClass().toString());
		headers.add("content-length", "10");
		headers.add("Content-Type", "text/plain; charset=utf-16");
		headers.add("refresh", "5;url=http://localhost:9090/CustomerModule/");
		return ResponseEntity.accepted().headers(headers).body(str);
	}

}




