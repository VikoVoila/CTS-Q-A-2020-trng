import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-seller-registration',
  templateUrl: './seller-registration.component.html',
  styleUrls: ['./seller-registration.component.css']
})
export class SellerRegistrationComponent implements OnInit {

  form = new FormGroup({
    userName: new FormControl('', Validators.required),
    cName: new FormControl('', Validators.required),
    phone: new FormControl('', Validators.required),
    companyDescription: new FormControl("", Validators.required),
    postalAddress: new FormControl('', Validators.required),
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
    
   });

  constructor() { }

  ngOnInit(): void {
  }

}
