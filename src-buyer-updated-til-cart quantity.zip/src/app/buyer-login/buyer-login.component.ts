import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup } from '@angular/forms';
import { BuyerModel } from '../models/buyer.model';
import { Router } from '@angular/router';
import { BuyerLoginService } from '../service/buyer-login.service';

@Component({
  selector: 'app-buyer-login',
  templateUrl: './buyer-login.component.html',
  styleUrls: ['./buyer-login.component.css']
})
export class BuyerLoginComponent implements OnInit {

  form = new FormGroup({
    userName: new FormControl('', Validators.required),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
    
   });

   buyer: BuyerModel = new BuyerModel();

  constructor(private router: Router, private buyerRegistrationService: BuyerLoginService) { }

  ngOnInit(): void {
  }

  buyerLogin() {
    console.log(this.buyer.emailId);
    this.buyerRegistrationService.buyerLogin(this.buyer)
        .subscribe( () => {
          alert("Buyer created successfully.");
        });
  }

  onSubmit(){
    alert(JSON.stringify(this.form.value));
    //this.buyerLogin();
  }

}
