export class CartModel {
    cartItemId:number;
    itemId: number;
    quantity: number;
    //name:string;
    buyer:number;
}