package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.voila.demo.model.BuyerInfo;
import com.voila.demo.model.CartItems;
import com.voila.demo.repository.BuyerRepository;
import com.voila.demo.repository.CartItemRepository;

@Service
public class CartItemService {
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	/*
	 * @Autowired private BuyerRepository buyerRepository;
	 */

	public List<CartItems> getAllCartItems() {
		// TODO Auto-generated method stub
		List<CartItems> allCartItems = new ArrayList<CartItems>();
		cartItemRepository.findAll().forEach(allCartItems::add);
		/* cartItemRepository.findAll().forEach(allCartItems::add); */
		return allCartItems;
	}

	public CartItems addCartItem(CartItems newCartItems, Integer buyerId) {
		// TODO Auto-generated method stub
		System.out.println("In service");
		Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
		newCartItems.setBuyer(buyer.get());
		return cartItemRepository.save(newCartItems);
		
	}
	
	public List<CartItems> getCartItems( Integer buyerId) {
		// TODO Auto-generated method stub
		
		return cartItemRepository.getCartItemByBuyerId(buyerId);
	}
	
	public CartItems incDecItem(CartItems newCartItem) {
		System.out.println("In cart qty update service");
		//Optional<BuyerInfo> buyer = buyerRepository.findById(buyerId);
		Optional<CartItems> cartItem = cartItemRepository.findById(newCartItem.getCartItemId());
		System.out.println(cartItem.get());
		if(cartItem.isPresent()) {
			CartItems updatedCartItem = cartItem.get();
			System.out.println(newCartItem.getQuantity());
			updatedCartItem.setQuantity(newCartItem.getQuantity());
			System.out.println(newCartItem.getQuantity());
			return cartItemRepository.save(updatedCartItem);
			
		}
		return null;
	}
	
	
	
}
