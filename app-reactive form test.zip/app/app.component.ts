import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  myForm: FormGroup;

  //constructor(private fb: FormBuilder) {}
  constructor() {}

  ngOnInit() {
  this.myForm = new FormGroup({
    name: new FormControl('Voila26', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.pattern('[a-z0-9.@]*')]),
    messagetxt: new FormControl('', [Validators.required]) //'', [Validators.required, Validators.minLength(15)])
  });
  }

  onSubmit(form: FormGroup) {
    console.log('Valid?', form.valid); // true or false
    console.log('Name', form.value.name);
    console.log('Email', form.value.email);
    console.log('Messagetxt', form.value.messagetxt);
  }
}
