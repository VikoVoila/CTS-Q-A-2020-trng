import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BuyerRegistrationService } from '../service/buyer-registration.service';
import { BuyerModel } from '../models/buyer.model';

@Component({
  selector: 'app-buyer-signup',
  templateUrl: './buyer-signup.component.html',
  styleUrls: ['./buyer-signup.component.css']
})
export class BuyerSignupComponent implements OnInit {
  form = new FormGroup({
    userName: new FormControl('', Validators.required),
    phone: new FormControl('', Validators.required),
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
    
   });

   buyer: BuyerModel = new BuyerModel();

  constructor(private router: Router, private buyerRegistrationService: BuyerRegistrationService ) { }

  get firstname(){
    return this.form.get('userName')
  }
  ngOnInit(): void {
  }

  createBuyer(): void {
    console.log(this.buyer.emailId);
    this.buyerRegistrationService.createbuyer(this.buyer)
        .subscribe( () => {
          alert("Buyer created successfully.");
        });

  };

  onSubmit(){
    //alert(JSON.stringify(this.form.value));
    this.createBuyer();
  }

}
