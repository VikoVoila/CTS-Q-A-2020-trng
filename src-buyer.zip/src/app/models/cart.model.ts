export class CartModel {
    itemId: number;
    quantity: number;
    //name:string;
    buyer:number;
}