import { Component, OnInit } from '@angular/core';
import { CartModel } from '../models/cart.model';
import { Router } from '@angular/router';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})


export class CartComponent implements OnInit {


  cartItems : CartModel[];
  item : CartModel;
  constructor(private router: Router, private cartService: CartService ) { }

  ngOnInit(): void {
    this.showCartItems();
  }

  showCartItems(): void {
    //console.log(this.buyer.emailId);
    this.cartService.showCartItems()
        .subscribe(cartItem => this.cartItems = cartItem);
  }

  increase(cart : CartModel) {
    cart.quantity += 1;
    this.cartService.update(cart).subscribe(item => this.item = item);
  }
}
