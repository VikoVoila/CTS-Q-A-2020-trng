import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { SellerModel } from '../models/seller.model';
import { SellerRegistrationService } from '../service/seller-registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seller-registration',
  templateUrl: './seller-registration.component.html',
  styleUrls: ['./seller-registration.component.css']
})
export class SellerRegistrationComponent implements OnInit {

  registration: FormGroup;
  seller: any;

  // seller: SellerModel = new SellerModel();

  constructor(private formBuilder: FormBuilder, private router: Router, private sellerRegistrationService: SellerRegistrationService) { }

  ngOnInit(): void {
    this.registration = this.formBuilder.group({
      sellerName: new FormControl('', Validators.required),
      companyName: new FormControl('', Validators.required),
      companyDescription: new FormControl('', Validators.required),
      cWebsite: new FormControl('', Validators.required),
      gstin: new FormControl('', Validators.required),
     // postalAddress: new FormControl('', Validators.required),
      houseNumber: new FormControl('', Validators.required),
      streetName: new FormControl('', Validators.required),
      locality: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required),
      state: new FormControl('', Validators.required),
      pinCode: new FormControl('', [
        Validators.required,
        Validators.pattern("^[0-9]*$"),
        Validators.maxLength(6),
        Validators.minLength(6)
      ]),
      phone: new FormControl('', [
        Validators.required,
        Validators.pattern("^[0-9]*$"),
        Validators.maxLength(10),
        Validators.minLength(10)
      ]),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(6)
      ])
    })
  }

  createSeller(): void {
    console.log(this.seller.emailId);
    this.sellerRegistrationService.createSeller(this.seller)
      .subscribe(() => {
        alert("Buyer created successfully.");
      });

  };

  // convenience getter for easy access to form fields
  // get form1() { return this.form.controls; }

  onSubmit() {
    console.log("on click1")
    // if (this.registration.invalid) {
    //   return;
    // }
    console.log("on click")
    this.seller = new SellerModel();
    this.seller.name = this.registration.controls.sellerName.value;
    this.seller.password = this.registration.controls.password.value;
    this.seller.companyName = this.registration.controls.companyName.value;
    this.seller.companyDescription = this.registration.controls.companyDescription.value;
    this.seller.website = this.registration.controls.cWebsite.value;
    this.seller.gstin = this.registration.controls.gstin.value;
    this.seller.postalAddress.houseNumber = this.registration.controls.houseNumber.value;
    this.seller.postalAddress.streetName = this.registration.controls.streetName.value;
    this.seller.postalAddress.locality = this.registration.controls.locality.value;
    this.seller.postalAddress.city = this.registration.controls.city.value;
    this.seller.postalAddress.state = this.registration.controls.state.value;
    this.seller.postalAddress.pinCode = this.registration.controls.pinCode.value;
    this.seller.mobileNo = this.registration.controls.phone.value;
    this.seller.emailId = this.registration.controls.email.value;
    console.log("on click2")
    this.sellerRegistrationService.createSeller(this.seller).subscribe(() => {
      alert("Registered successfully!!!");
    });


    //alert(JSON.stringify(this.form.value));
    // this.createSeller();
  }

}
