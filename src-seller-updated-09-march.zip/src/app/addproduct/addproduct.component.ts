import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  City: any = ['Florida', 'South Dakota', 'Tennessee', 'Michigan']
  
  form = new FormGroup({
    productName: new FormControl('', Validators.required),
    manufacturerName: new FormControl('', Validators.required),
    modelName: new FormControl('', Validators.required),
    price: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\d+\.\d{2}$/),  
    ]),
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
    
   });

  constructor() { }

  get firstname(){
    return this.form.get('firstName')
  }

  ngOnInit(): void {
  }

  onSubmit(){
    alert(JSON.stringify(this.form.value));
  }

}
