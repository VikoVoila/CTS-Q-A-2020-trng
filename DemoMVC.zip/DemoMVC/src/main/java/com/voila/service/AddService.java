package com.voila.service;

public class AddService {
	public int add(int i, int j) {
		return i+j;
	}
}
