	package Voila.EmployeeDetailstable;
	
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
	import org.hibernate.cfg.Configuration;
	
	import com.voila.onetoone.mapping.UserDetails;
	import com.voila.onetoone.mapping.Vehicle;
	
	
	
	
	
	
	/**
	 * Hello world!
	 *
	 */
	public class App 
	{
	    public static void main( String[] args )
	    {
	    	
	    	
		/*
		 * Configuration configuration=new Configuration().configure(); SessionFactory
		 * sf=configuration.buildSessionFactory(); Session session=sf.openSession();
		 */
	    	
	    	UserDetails user= new UserDetails(); 
	    	user.setUserName("First User");
	    	
	    	Vehicle vehicle = new Vehicle();
	    	vehicle.setVehicleName("Car");
	    	
	    	user.setVehicle(vehicle);
	    	
	    	SessionFactory sf=new Configuration().configure().buildSessionFactory();
	    	Session session= sf.openSession();
	    	
	    	session.beginTransaction();
	    	session.save(user);
	    	session.save(vehicle);
	    	session.getTransaction().commit();
	    	
	    	session.close();
	    	
	    	
			/*
			 * UserDetails user= new UserDetails(); user.setUserName("First User"); Vehicle
			 * vehicle=new Vehicle(); vehicle.setVehicleName("Car");
			 * session.beginTransaction();
			 * 
			 * session.save(user); session.save(vehicle); session.getTransaction().commit();
			 * session.close();
			 */
	    }
	}
