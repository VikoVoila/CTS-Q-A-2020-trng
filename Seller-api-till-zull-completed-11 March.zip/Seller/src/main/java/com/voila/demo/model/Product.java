
package com.voila.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer productId;
	
	@Column(name="product_name")
	private String productName;
	
	/* @Column(name="manufacturer") */
	@Column
	private String manufacturer;
	
	/* @Column(name="model") */
	@Column
	private String model;
	
//	
	@ManyToOne
	@JoinColumn(name = "seller_id")
	private Seller seller;
	
	
	@Column(name="product_price")
	private Double price;
	
	private Integer stock;
	
	@ManyToOne
	@JoinColumn(name="category_id")
	private Category categoryId;
	
	@ManyToOne
	@JoinColumn(name = "sub_category_id")
	private SubCategory subCategoryId;
	
	@Column(name="description")
	private String decription;
	
	private String remarks;


	public Product(String productName, String manufacturer, String model, Seller seller, Double price,
			Integer stock, Category categoryId, SubCategory subCategoryId, String decription, String remarks) {
		super();
		this.productName = productName;
		this.manufacturer = manufacturer;
		this.model = model;
		this.seller = seller;
		this.price = price;
		this.stock = stock;
		this.categoryId = categoryId;
		this.subCategoryId = subCategoryId;
		this.decription = decription;
		this.remarks = remarks;
	}



	public Product() {
		super();
	}

	

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	


	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Seller getSeller() {
		return seller;
	}
	


	public void setSeller(Seller seller) {
		this.seller = seller;
	}



	public String getManufacturer() {
		return manufacturer;
	}



	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}



	public Double getPrice() {
		return price;
	}



	public void setPrice(Double price) {
		this.price = price;
	}



	public Integer getStock() {
		return stock;
	}



	public void setStock(Integer stock) {
		this.stock = stock;
	}



	public Category getCategoryId() {
		return categoryId;
	}



	public void setCategoryId(Category categoryId) {
		this.categoryId = categoryId;
	}



	public SubCategory getSubCategoryId() {
		return subCategoryId;
	}



	public void setSubCategoryId(SubCategory subCategoryId) {
		this.subCategoryId = subCategoryId;
	}



	public String getDecription() {
		return decription;
	}



	public void setDecription(String decription) {
		this.decription = decription;
	}



	public String getRemarks() {
		return remarks;
	}



	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}



	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", manufacturer=" + manufacturer
				+ ", model=" + model + ", seller=" + seller + ", price=" + price + ", stock="
				+ stock + ", categoryId=" + categoryId + ", subCategoryId=" + subCategoryId + ", decription="
				+ decription + ", remarks=" + remarks + "]";
	}

	
	
	
}
