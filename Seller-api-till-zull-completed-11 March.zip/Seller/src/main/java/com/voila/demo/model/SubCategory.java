package com.voila.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * Date :Feb 18,2020
 * @author Vivek
 * @version 1.0
 *
 */

@Entity
public class SubCategory {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int subCategoryId;
	
	@Column(name = "sub_category_name")
	private String subCategoryName;
	
	@Column(name = "category_details")
	private String briefDetails;
	
	@ManyToOne
	@JoinColumn(name = "categoryId")
	private Category category;
	
	private Integer gst;

	
	public SubCategory(String subCategoryName, String briefDetails, Category category, Integer gst) {
		super();
		this.subCategoryName = subCategoryName;
		this.briefDetails = briefDetails;
		this.category = category;
		this.gst = gst;
	}



	public SubCategory() {
		super();
	}
	
	
	
	

	public int getSubCategoryId() {
		return subCategoryId;
	}



	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}



	public String getSubCategoryName() {
		return subCategoryName;
	}



	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}



	public String getBriefDetails() {
		return briefDetails;
	}



	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}



	public Category getCategory() {
		return category;
	}



	public void setCategory(Category category) {
		this.category = category;
	}



	public Integer getGst() {
		return gst;
	}



	public void setGst(Integer gst) {
		this.gst = gst;
	}



	@Override
	public String toString() {
		return "SubCategory [subCategoryId=" + subCategoryId + ", subCategoryName=" + subCategoryName
				+ ", briefDetails=" + briefDetails + ", category=" + category + ", gst=" + gst + "]";
	}



	
	
	

}
