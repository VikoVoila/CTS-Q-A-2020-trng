import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SellerRegistrationService } from '../service/seller-registration.service';
import { SellerModel } from '../models/seller.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seller-registration',
  templateUrl: './seller-registration.component.html',
  styleUrls: ['./seller-registration.component.css']
})
export class SellerRegistrationComponent implements OnInit {

  form = new FormGroup({
    userName: new FormControl('', Validators.required),
    companyName: new FormControl('', Validators.required),
    phone: new FormControl('', Validators.required),
    companyDescription: new FormControl('', Validators.required),
    gstin: new FormControl('', Validators.required),
    cWebsite: new FormControl('', Validators.required),
    postalAddress: new FormControl('', Validators.required),
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ])
    
   });

   seller: SellerModel = new SellerModel();

  constructor( private router: Router, private sellerRegistrationService: SellerRegistrationService ) { }

  ngOnInit(): void {
  }

  craeteSeller() {
    this.sellerRegistrationService.createSeller(this.seller)
    .subscribe( () => {
      alert("Seller created successfully.");
    }); 
  }

  onSubmit(){
    //alert(JSON.stringify(this.form.value));
    this.craeteSeller();
  }

}
