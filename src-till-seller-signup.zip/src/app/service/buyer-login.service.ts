import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BuyerModel } from '../models/buyer.model';
import { Observable } from 'rxjs';
import { BuyerLoginComponent } from '../buyer-login/buyer-login.component';

@Injectable({
  providedIn: 'root'
})
export class BuyerLoginService {

  constructor(private http:HttpClient) { }

  private baseUrl = "http://localhost:8182/";

  public buyerLogin(buyer: BuyerModel):Observable<any> {
    return this.http.get<BuyerLoginComponent>(this.baseUrl+'/buyersinfo/3');
  }
}
