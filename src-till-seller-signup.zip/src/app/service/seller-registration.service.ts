import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SellerModel } from '../models/seller.model';
import { Observable } from 'rxjs';
import { SellerRegistrationComponent } from '../seller-registration/seller-registration.component';

@Injectable({
  providedIn: 'root'
})
export class SellerRegistrationService {

  constructor(private http: HttpClient) { }

  private baseUrl = "http://localhost:8182/";

  public createSeller(seller: SellerModel):Observable<any> {
    console.log("in service");
    return this.http.post<SellerRegistrationComponent>(this.baseUrl+'/newSeller', seller);
  }

}
