import { TestBed } from '@angular/core/testing';

import { BuyerRegistrationService } from './buyer-registration.service';

describe('BuyerRegistrationService', () => {
  let service: BuyerRegistrationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BuyerRegistrationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
