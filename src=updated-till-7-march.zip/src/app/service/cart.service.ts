import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CartModel } from '../models/cart.model';
import { Observable } from 'rxjs';
import { CartComponent } from '../cart/cart.component';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http:HttpClient) { }

  private baseUrl = "http://localhost:8080/";

  public showCartItems():Observable<any> {
    return this.http.get(this.baseUrl+'/3/getcartitems');
  }

  public update(cart: CartModel):Observable<any> {
    return this.http.put<CartComponent>(this.baseUrl+'/cartitem/3', cart);
  }

}
