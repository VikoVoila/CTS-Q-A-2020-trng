import { Component, OnInit } from '@angular/core';
import { ProductsModel } from '../models/products.model';
import { ProductService } from '../service/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showproducts',
  templateUrl: './showproducts.component.html',
  styleUrls: ['./showproducts.component.css']
})
export class ShowproductsComponent implements OnInit {

  allProducts : ProductsModel[];
  product: ProductsModel;

  constructor( private router: Router, private productService: ProductService ) { }

  ngOnInit(): void {
    this.Products();
  }

  Products(): void{
    this.productService.showAllProducts()
    .subscribe(allItem => this.allProducts = allItem);
  }

  addtoCart(product: ProductsModel) {
    // product.quantity = 1;
    console.log(product);
    this.productService.addToCart(product).subscribe(allitem => this.allProducts = allitem);
  }

}
