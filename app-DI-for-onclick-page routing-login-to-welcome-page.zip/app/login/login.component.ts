import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = "voila2678";
  password = "";
  errorMessage = "Invalid Credentials! ";
  invalidLogin = false;
  

  // Router
  // Angular.giveMeRouter
  // Depenedency Injection

  constructor(private router: Router) { }

  ngOnInit() {
  }

  handleLogin() {
    if (this.username === "voila2678" && this.password === "Voila2678") {
      // Redirect to welcome page
      this.router.navigate(['welcome'])
      this.invalidLogin = false;
    } else {
      this.invalidLogin = true;
    }
    console.log(this.username);
    // console.log(this.password);
  }

}
