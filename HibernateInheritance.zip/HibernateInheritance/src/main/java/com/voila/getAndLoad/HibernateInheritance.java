package com.voila.getAndLoad;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.voila.mypackage.Account;
import com.voila.mypackage.DemateAccount;
import com.voila.mypackage.SavingAccount;




/**
 * Hello world!
 *
 */
public class HibernateInheritance 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		
		Account acc=new Account();
		acc.setAccNum(1000);
		acc.setName("Voila");
		DemateAccount demat=new DemateAccount();
		demat.setAccNum(1001);
		demat.setName("Amit");
		demat.setShare(4);
		SavingAccount sacc=new SavingAccount();
		sacc.setAccNum(1002);
		sacc.setInterestRate(9.7f);
		sacc.setName("Ramesh");
		session.beginTransaction();
		session.save(acc);
		session.save(sacc);
		session.save(demat);
		DemateAccount demat1=new DemateAccount();
		demat1.setAccNum(1004);
		demat1.setName("Mukesh");
		demat1.setShare(8);
		session.save(demat1);		
		session.getTransaction().commit();
		session.close();
		
				
		
    }
}
