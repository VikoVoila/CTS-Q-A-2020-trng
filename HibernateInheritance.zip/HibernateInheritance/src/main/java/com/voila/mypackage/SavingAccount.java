package com.voila.mypackage;

import javax.persistence.Entity;

@Entity
//@PrimaryKeyJoinColumn(name="account_number")
public class SavingAccount extends Account {
	//account_number
	
	private float interestRate;

	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}
	
}
