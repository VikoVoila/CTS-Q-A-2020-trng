package com.voila.mypackage;

import javax.persistence.Embeddable;
import javax.persistence.Entity;


@Entity
//@PrimaryKeyJoinColumn(name="acc_numb")
public class DemateAccount extends Account{
//acc_numb
	private int share;

	public int getShare() {
		return share;
	}

	public void setShare(int share) {
		this.share = share;
	} 
	
}
