package com.cts.voila;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.voila.Product;
import com.cts.voila.ProductDao;

@Component
public class ProductDaoService {
	
	@Autowired
	ProductDao pDao;
	
	//ADDING PRODUCT
	
	public int addProduct(Product product) {
		
		return pDao.addProduct(product);
	}
	
  public Product getById(int prodId) {
		
		return pDao.getById(prodId);
	}

public int delProduct(int prodId) {
	// TODO Auto-generated method stub
	return pDao.delProduct(prodId);
}

}
