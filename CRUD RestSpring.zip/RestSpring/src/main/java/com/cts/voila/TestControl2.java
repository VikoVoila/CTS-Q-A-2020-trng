package com.cts.voila;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.voila.Product;

@RestController
public class TestControl2 {
	/*
	 * @Autowired Product product;
	 */
	@Autowired
	ProductDaoService pServ;
	@RequestMapping(value = "/product", method = RequestMethod.POST, produces = "application/json")
	public int addProduct(@RequestBody Product product) {

		return pServ.addProduct(product);
	}
	
	// Delete by id
	@RequestMapping(value="/delete/{prodId}", method=RequestMethod.DELETE)
	public ResponseEntity<Product> deleteProduct(@PathVariable("prodId") int
			  prodId){ 
				HttpHeaders headers = new HttpHeaders(); Product product =
			  pServ.getById(prodId); 
			  if(product == null) { return new
			    ResponseEntity<Product>(HttpStatus.NOT_FOUND); 
			  }
			    pServ.delProduct(prodId); headers.add("Product Deleted - ",
			  String.valueOf(prodId));
			  return new  ResponseEntity<Product>(product,headers,HttpStatus.NO_CONTENT); 
		}
			 
	// get by id
	@RequestMapping(value="/getbyid/{prodId}",method=RequestMethod.GET) public
	  ResponseEntity<Product> getById(@PathVariable("prodId") int prodId) { Product
	  product = pServ.getById(prodId); if(product == null) { return new
	  ResponseEntity<Product>(HttpStatus.NOT_FOUND); }
	  
	  return new ResponseEntity<Product>(product,HttpStatus.OK); }

}
