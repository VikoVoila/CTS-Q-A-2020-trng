package com.cts.voila;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cts.voila.Product;

@Repository
public class ProductDao {
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	
	//SETTER FOR JDBC TEMPLATE
	
		public void setJdbc(JdbcTemplate jdbc) {
			
			this.jdbc = jdbc;
		}
		
		public int addProduct(Product product) {
			
			jdbc = new JdbcTemplate(ds);
			System.out.println("hello: add product performed");
			int storedStatus = jdbc.update("INSERT INTO Product VALUES(?,?,?,?)", new Object[] {product.getId(),product.getName(),product.getQuantity(),product.getPrice()});
			System.out.println(storedStatus);
			return product.getId();
			
		}
		
		//delete
		public int delProduct(int prodId) {
			jdbc = new JdbcTemplate(ds);
			int count = jdbc.update("DELETE FROM PRODUCT WHERE PROD_ID=?", new Object[] {prodId});
			return count;
		}
		
		//GETBYID
		public Product getById(int prodId) {
			jdbc = new JdbcTemplate(ds);
			String sql = "SELECT * FROM product WHERE prod_id=?";
			Product product = (Product)jdbc.queryForObject(sql, new Object[] {prodId},

					new RowMapper<Product>() {
				public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

					Product product = new Product();

					product.setId(rs.getInt(1));
					product.setName(rs.getString(2));
					product.setQuantity(rs.getInt(3));
					product.setPrice(rs.getFloat(4));

					return product;
				}

			});
			return product;
		}

}
