import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { BuyerSignupComponent } from '../buyer-signup/buyer-signup.component';
import { BuyerModel } from '../models/buyer.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BuyerRegistrationService {

  constructor(private http:HttpClient) { }

  private baseUrl = "http://localhost:8080";
  // private baseUrl = "http://localhost:8080/buyerService";

  public createbuyer(buyer: BuyerModel):Observable<any> {
    return this.http.post<BuyerSignupComponent>(this.baseUrl+'/buyersinfo', buyer);
  }
}
