import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyerLogoutComponent } from './buyer-logout.component';

describe('BuyerLogoutComponent', () => {
  let component: BuyerLogoutComponent;
  let fixture: ComponentFixture<BuyerLogoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyerLogoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyerLogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
