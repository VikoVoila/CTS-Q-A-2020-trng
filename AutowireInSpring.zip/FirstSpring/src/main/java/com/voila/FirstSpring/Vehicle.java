package com.voila.FirstSpring;

public interface Vehicle {
	void drive();

}
