import { Component, OnInit } from '@angular/core';
//import { AppComponent } from '../app.component';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  message : String = 'some welcome message' //member variable

  constructor() { }

  ngOnInit() {
    //this.message=3; // thi wil show error cause of message type is string
    console.log(this.message);
  }

} 

export class class1{

}