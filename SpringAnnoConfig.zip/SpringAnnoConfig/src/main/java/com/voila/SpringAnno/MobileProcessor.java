package com.voila.SpringAnno;

public interface MobileProcessor {
	
	void process();

}
