import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { BuyerModel } from '../models/buyer.model';
import { Router } from '@angular/router';
import { BuyerLoginService } from '../service/buyer-login.service';

@Component({
  selector: 'app-buyer-login',
  templateUrl: './buyer-login.component.html',
  styleUrls: ['./buyer-login.component.css']
})
export class BuyerLoginComponent implements OnInit {

  loginForm: FormGroup;
  invalidLogin: boolean = false;



  // buyer: BuyerModel = new BuyerModel();

  constructor(private formBuilder : FormBuilder, private router: Router, private buyerRegistrationService: BuyerLoginService) { }
  userForm : any;
  ngOnInit(): void {
    window.localStorage.removeItem('token');
    this.loginForm = this.formBuilder.group({
      name: ['',[Validators.required]],
      password: ['',[Validators.required]],
    });
  }

  // buyerLogin() {
  //   console.log(this.buyer.emailId);
  //   this.buyerRegistrationService.buyerLogin(this.buyer)
  //       .subscribe( () => {
  //         alert("Buyer created successfully.");
  //       });
  // }

  onSubmit(){
    if (this.loginForm.invalid) {
      return;
    }
    console.log("clicked 1 ")
    const loginPayload = {
      username: this.loginForm.controls.name.value,
      password: this.loginForm.controls.password.value
    }
    this.buyerRegistrationService.login(loginPayload).subscribe(data => {
      //debugger;
      if(data.status === 200) {
        window.localStorage.setItem('token', data.result.token);
        window.localStorage.setItem('name', data.result.username);
        window.localStorage.setItem('id', data.result.buyerId);
        alert("login successful");
        this.router.navigateByUrl("/products");
      }else {
        this.invalidLogin = true;
        alert(data.message);
      }
    });
    console.log("clicked 2 ")
  }

}
