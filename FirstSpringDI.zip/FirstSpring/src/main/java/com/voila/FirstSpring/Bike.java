package com.voila.FirstSpring;

public class Bike implements Vehicle{
	
	public void drive() {
		System.out.println("Bike Bhag rhai h..");
	}
}
