package com.voila.demo.model.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;


import com.voila.demo.model.Seller;
import com.voila.demo.repository.AddressRepository;
import com.voila.demo.repository.SellerRepository;



@Service
public class SellerService implements UserDetailsService {
	
	@Autowired
	private SellerRepository sellerRepository;
	
	@Autowired 
	private AddressRepository addressRepository;
	
	// added 10 march 
	
		@Autowired
		private BCryptPasswordEncoder bcryptEncoder;

		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			Seller seller = sellerRepository.findByName(username);
			if(seller == null){
				throw new UsernameNotFoundException("Invalid username or password.");
			}
			return new org.springframework.security.core.userdetails.User(seller.getName(), seller.getPassword(), getAuthority());
		}

		private List<SimpleGrantedAuthority> getAuthority() {
			return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
		}
		
		// end of added 10 march
	
	public List<Seller> getAllSellers(){
		List<Seller> sellerRecord = new ArrayList<Seller>();
		sellerRepository.findAll().forEach(sellerRecord::add);    
		return sellerRecord;
	}
	
	// add new seller details
	public Seller addSeller(Seller seller) {
		Seller newSeller = new Seller();
		newSeller.setName(seller.getName());
		newSeller.setPassword(bcryptEncoder.encode(seller.getPassword()));
		newSeller.setCompanyName(seller.getCompanyName());
		newSeller.setCompanyDescription(seller.getCompanyDescription());
		newSeller.setEmailId(seller.getEmailId());
		newSeller.setGstin(seller.getGstin());
		newSeller.setMobileNo(seller.getMobileNo());
		newSeller.setPostalAddress(seller.getPostalAddress());
		newSeller.setWebsite(seller.getWebsite());
		addressRepository.save(seller.getPostalAddress());
		return sellerRepository.save(newSeller);
		
	}
	

	
	/*
	 * public BuyerInfo getBuyerById(BuyerInfo buyer) { return
	 * buyerRepository.findAll(id); }
	 */
	// getById method
	public Optional<Seller> getSeller(@PathVariable Integer sellerId) {
		return sellerRepository.findById(sellerId);
				/*.orElseThrow(()-> new BuyerInfoNotFoundException(id));*/
	}
	
	// Delete Seller BL
	public void deleteSeller(Integer sellerId) {
		// TODO Auto-generated method stub
		sellerRepository.deleteById(sellerId);
	}
	
	// Update Seller BL
	public Seller saveOrUpdate(Seller seller, Integer id, String emailId, Date date ) {
		// TODO Auto-generated method stub
		/* buyerRepository.save(buyerInfo); */
		Optional<Seller> buyer = sellerRepository.findById(id);
		seller.setEmailId(emailId);
		return sellerRepository.save(seller);
		
		
		// here onward we have to complete
		
	}

	public Seller findOne(String username) {
		// TODO Auto-generated method stub
		return sellerRepository.findByName(username);
	}
	
}
