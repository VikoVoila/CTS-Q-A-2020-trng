import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showallproducts',
  templateUrl: './showallproducts.component.html',
  styleUrls: ['./showallproducts.component.css']
})
export class ShowallproductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
