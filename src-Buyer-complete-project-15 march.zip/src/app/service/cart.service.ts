import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CartModel, CartCheckOut } from '../models/cart.model';
import { Observable } from 'rxjs';
import { CartComponent } from '../cart/cart.component';
import { Stock } from '../models/products.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http:HttpClient) { }

  buyerId: string = window.localStorage.getItem('id');

  // private baseUrl = "http://localhost:8080";
  private baseUrl = `http://localhost:8989/mentorportal/buyerService`;
  

  public showCartItems():Observable<any> {
    return this.http.get(this.baseUrl+`/${this.buyerId}/getcartitems`);
  }

  public update(cart: CartModel):Observable<any> {

    return this.http.put<CartComponent>(this.baseUrl+`/cartitem/${this.buyerId}`, cart);
  }
  // private baseUrl1 = "http://localhost:8080/deletecartitem";
  private baseUrl1 = `http://localhost:8989/mentorportal/buyerService/deletecartitem`;

  deleteCartItem(cartItemId: number): Observable<any> {
    // return this.http.delete(`${this.baseUrl1}/${cartItemId}`);
    return this.http.delete(`http://localhost:8989/mentorportal/buyerService/deletecartitem/${cartItemId}`);
  }

  // private baseUrl2 = `http://localhost:8080/cartitems/checkout`;
  public checkout(checkout: CartCheckOut):Observable<any> {
    console.log("in checkout service")
    return this.http.post(`http://localhost:8989/mentorportal/buyerService/cartitems/checkout/${this.buyerId}`, checkout)
    console.log("in checkout service ending")
  }
   
  // public checkout():Observable<any> {
  //   console.log("in checkout service")
  //   return this.http.get(`http://localhost:8989/mentorportal/buyerService/cartitems/checkout/${this.buyerId}`)
  //   console.log("in checkout service ending")
  // }

  updateStock(cartItems: Stock[]) {
   // return this.http.put(`http://localhost:8080/seller/updatestock`,cartItems);
   console.log("hi in update stock")
    return this.http.put(`http://localhost:8989/mentorportal/sellerService/updatestock`,cartItems);
  }

}
