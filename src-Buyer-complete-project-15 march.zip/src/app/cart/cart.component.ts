import { Component, OnInit } from '@angular/core';
import { CartModel, CartCheckOut } from '../models/cart.model';
import { Router } from '@angular/router';
import { CartService } from '../service/cart.service';
import { ProductsModel, Stock } from '../models/products.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})


export class CartComponent implements OnInit {

  product: ProductsModel[];
  cartItems : CartModel[];
  item : CartModel;
  totalPrice:number=0;
  shopcart: CartCheckOut = new CartCheckOut();
  stock: Stock[];
  storeStock: Stock;
  constructor(private router: Router, private cartService: CartService ) { }
  
  ngOnInit(): void {
    this.showCartItems();
  }

  showCartItems(): void {
    //console.log(this.buyer.emailId);
    this.cartItems
    this.cartService.showCartItems()
        .subscribe(cartItem => {this.cartItems = cartItem;
          this.totalPrice=0;
          this.cartItems.forEach(element => {
          
           
            this.totalPrice = this.totalPrice + element.price*element.quantity
           
          });
          console.log("hi"+this.totalPrice)
        }
          
            
          );
  }

  
  increase(cart : CartModel) {
    cart.quantity += 1;
    this.cartService.update(cart).subscribe(item => {this.item = item;
    this.showCartItems();
    });
  }

  decrease(cart : CartModel) {
    if(cart.quantity == 0){
      return alert("Can't be Decrease")
    }
    cart.quantity -= 1;
    this.cartService.update(cart).subscribe(item => {this.item = item;
    this.showCartItems();
    });
    
  }

  // totalPrice(){
  //   var total =0;
  //   this.cartItems.forEach(element => {
  //     console.log("total p 1 "+total)
  //       // total +=;
  //   });
  //   console.log("total p "+total)
  //   return total;
  // }
  
  

  deleteCartItem(cart: CartModel): void {
    this.cartService.deleteCartItem(cart.cartItemId)
      .subscribe( data => {
        this.cartItems = this.cartItems.filter(u => u !== cart);
        this.showCartItems();
        alert(cart);
      })
  };

  updateStock() {
    this.stock = new Array();
    console.log("fhjfjgj");
    for(let cartItem of this.cartItems){
        this.storeStock= new Stock();
        this.storeStock.itemId= cartItem.itemId;
        this.storeStock.quantity = cartItem.quantity;
        this.stock.push(this.storeStock);
    }
    this.cartService.updateStock(this.stock).subscribe(() => 
    {
      this.totalPrice = 0;
      this.showCartItems();
    });
  }

  // cartcheckout(){
  //   console.log("cl ")
  //   this.cartService.checkout().subscribe(() => this.updateStock())
  //   // (newview => this.cartService=newview));
  // }
  cartcheckout(checkout: CartCheckOut){
    console.log("cl ")
    this.cartService.checkout(checkout).subscribe(() => 
    {
      console.log("cl 1");
      this.updateStock();
    });
    this.ngOnInit();
    // (newview => this.cartService=newview));
  }


}
