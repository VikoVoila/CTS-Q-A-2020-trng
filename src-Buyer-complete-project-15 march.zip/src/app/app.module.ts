import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CartComponent } from './cart/cart.component';
import { BuyerLoginComponent } from './buyer-login/buyer-login.component';
import { ShowproductsComponent } from './showproducts/showproducts.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { BuyerLogoutComponent } from './buyer-logout/buyer-logout.component';
import { TokenInterceptor } from './interceptor';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    BuyerSignupComponent,
    HomeComponent,
    CartComponent,
    BuyerLoginComponent,
    ShowproductsComponent,
    CheckoutComponent,
    BuyerLogoutComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers : [ {provide: HTTP_INTERCEPTORS,
  useClass : TokenInterceptor,
  multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
