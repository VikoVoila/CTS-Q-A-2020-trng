package com.voila.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="transaction")
public class Transactions {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="transcation_id")
	private int transactionId;
	
	@Column(name="transaction_type")
	private String transactiontype;
	
	@ManyToOne
	@JoinColumn(name = "buyer_id")
	private BuyerInfo buyer;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;
	
	private Double totalAmount;
	
	private String remarks;
	
	

	public Transactions(String transactiontype, BuyerInfo buyer, Date date, String remarks, Double totalAmount) {
		super();
		this.transactiontype = transactiontype;
		this.buyer = buyer;
		this.date = date;
		this.remarks = remarks;
		this.totalAmount = totalAmount;
	}
	
	
	
	public Transactions() {
		super();
	}



	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}

	public BuyerInfo getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}



	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}



	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", transactiontype=" + transactiontype + ", buyer="
				+ buyer + ", date=" + date + ", totalAmount=" + totalAmount + ", remarks=" + remarks + "]";
	}
	

}
